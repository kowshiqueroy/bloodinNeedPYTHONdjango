from django.apps import AppConfig


class DataManageConfig(AppConfig):
    name = 'data_manage'
