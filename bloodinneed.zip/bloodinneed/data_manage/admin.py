from django.contrib import admin
from . models import Donor, Blog

# Register your models here.

admin.site.register(Donor)
admin.site.register(Blog)